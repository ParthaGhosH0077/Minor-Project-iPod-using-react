import music1 from "./stay.mp3";

const songs = {
	music1,
};

export default songs;
